http://code.google.com/p/printf-as3/

MIT Licence