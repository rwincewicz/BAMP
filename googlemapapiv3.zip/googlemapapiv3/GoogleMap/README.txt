GoogleMapAPIv3
=========================

Although this module is unofficial and may never see the light of day in terms
of publication as a Drupal contributed module, this folder is distributed empty
to be consistent with Drupal's policies and best practices related to 
incorporating third party code.

Before using this module you must get EITHER the GoogleMap.php file (and
optionally the JSMin.php companion file) from Brad Wedell or use my tweaked
version (see the module's README) from either:

  http://php-google-map-api.googlecode.com/svn/trunk/releases/3.0/src/

or:

  http://www.Sohodojo.biz/fyeo/GoogleMapAPI_class_tweaked.zip

Once downloaded, place the files in this folder.
