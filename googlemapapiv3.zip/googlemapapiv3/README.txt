GoogleMapAPIv3
=========================
This module provides a Drupal-friendly wrapper on Brad Wedell's PHP GoogleMapAPI
class with JS v3 support.

Features
=========================
1) A minimal wrapper on the GoogleMapAPI class. No admin UI, just an API for
   using this class in your themes and/or custom code.
   
2) Allows Drupal's database functions to handle database connection.

3) Provides a Drupal-based geocode cache.

4) Provides a means to work-around or fix the issue with "double ?" (more than
   one question mark character) in a Javascript include reference in theme 
   templates and/or custom code. (See Installation Instructions below
   for instructions on getting this to work.)

Installation Instructions
=========================
1) Download the module.

2) Unzip it into sites/all/modules and enable it in Drupal.

3) Get the GoogleMap.php file (and optionally the JSMin.php companion file) from
   Brad Wedell or use my tweaked version (see below) from either:
   
     http://php-google-map-api.googlecode.com/svn/trunk/releases/3.0/src/
     http://www.Sohodojo.biz/fyeo/GoogleMapAPI_class_tweaked.zip

   Once downloaded, place these files in the empty /googlemapapiv3/GoogleMap
   subdirectory of this module.

4) BEFORE referencing this module's API in your theme templates or custom code,
   you need to tweak any theme template through which you will include a 
   GoogleMapAPIv3 map. At a minimum, this means a slight tweak to your 
   page.tpl.php file. See the Fix Double-? Issue below.

5) Once you have the module enabled and one of the 'double-?' work-arounds in
   place, you can simply use Brad Wedell's API documentation to include 
   PHP-based Javascript generating code that uses the Version 3 GoogleMap API 
   in your themes or custom modules.

Fix Double-? Issue
=========================
One nice thing about the V.3 GoogleMap API is that API keys are no longer
required.

However, for licensing reasons with its third-party partners providing geocoding
information to Google every call into the GoogleAPI needs -- whether it's needed 
or not -- to have the GPS-related 'sensor' parameter included, e.g.
"http://maps.google.com/maps/api/js?sensor=false".

A problem you will have as a consequence of this is related to Drupal's (at
least in Drupal 6.x) cache-triggering mechanism. A '?x' appended to call to 
include a Javascript or CSS file with ensure that the most current version
of the file is accessed rather than a cached version. Obviously, this throws a
monkey-wrench into situations where the reference already includes a 
'?'-parameter portion in the include string. The second '?' would, in this
context, be an '&' rather than a '?'.

In addition, using drupal_add_js, such as:

  drupal_add_js('http://maps.google.com/maps/api/js?sensor=false', 'module',
    'header', FALSE, TRUE, FALSE);

can be problematic. Not only would this be hit with the 'double ?' issue, the
'http://' protocol reference to an external script can result in the string 
being prefixed with a '/' character as drupal_add_js assumes you are using a 
relatvie reference to a file on your server.

So you have two options:

Option A. Simply include the needed script including reference in your
          template file by adding the needed line in the header. For example,
          in page.tpl.php just after the CSS and Javascript script includes 
          of the theme-provided variable contents add this:

  <script type="text/javascript"
		src="http://maps.google.com/maps/api/js?sensor=false"></script>

Option B. Replace the 'scripts' variable substitution line in your template.
          Again for example, in page.tpl.php, change this line:

    <?php print $scripts; ?>

          to this:

    <?php print preg_replace('%(^.*<.*?)/(http.*?\?.*)\?(.*?>.*)%im', 
      '$1$2&$3', $scripts); ?>
    
          which uses a regular expression to fix both the external file and
double-? issues.

About the included files
=========================
When you download the currently available GoogleMapAPI source via:

  http://code.google.com/p/php-google-map-api/

there may be updates included so see the Project's documentation. Note, however,
that the version of GoogleMapAPI.php and JSMin.php downloadable from 
Sohodojo.biz are slightly modified to include these four differences:

  * The file-ending '?>' closing tag is removed as per the Drupal (and PHP.net)
    best practice.

  * The polyline-handling methods have been tweaked to recognize and
    appropriately implement the 'geodesic' option in V3's PolyLineOptions API.
    
  * A minor bug is fixed to enable shadow files for custom markers to display.

  * I've included mobcom's tweak to autoclose infowindows as per:
    http://code.google.com/p/php-google-map-api/issues/detail?id=22

All other needed (and important but not actually contributing to core
functionality) tweaks to the GoogleMapAPI class are made in the module as 
overrides in the GoogleMapAPIv3 subclass which is implemented in the module.

Essentially, these overrides are needed to massage the Javascript and
page-rendering generated code to be Drupal-friendly. That is, since the output 
of the 'stock' GoogleMapAPI class must pass through Drupal's various hook-based 
'gauntlet', some non-essential bits needed to be commented out to keep them 
from being visible on a Drupal page that includes a map generated by the 
original GoogleMapAPI class.

How to Use
=========================

The basic process of adding a GoogleMapAPIv3 map to your content is:

1) Create the Map object, do a bit of stock prep to ensure the rendered page
   will display the map.
   
2) Pull whatever Drupal data together than you need to build your map.

3) Use the PHP-based object methods to push your Drupal data through the
   PHP object into what will become the Javascript generated by the
   PHP object that will be run client-side on your output page.
   
Here's a skeletal cookbook of what the essentials of this look like:

  $my_map = new GoogleMapAPIv3();

  // Note: You can do whatever you need to do to pull your map together right
  // here. But let's push it down into a function call (see below).
  $themed_content = pull_my_map_together($my_map);

  // Add relevant Javascript to the header needed to render a client-side map.
  // Note: This is not needed if you hard-code add this script reference in your
  // page.tpl.php template file. If, however, you are using the regex fix so that
  // this is only added on-demand as needed, then include...
  drupal_add_js('http://maps.google.com/maps/api/js?sensor=false', 'module', 'header', FALSE, TRUE, FALSE);

  // Regardless of whether you use Option A or B to get the Google JS V3 API 
  // active, you will need this: 
  drupal_add_js($sn_map->getMapJS(), 'inline', 'header', FALSE, TRUE, FALSE);

  // Now the onload function which will take care of drawing the map.
  drupal_add_js('Drupal.behaviors.printMapOnLoad = function(context) 
    {this.onLoad' . $my_map->map_id . '();}' , 'inline');

  // Add the empty div where the map will be rendered client-side:
  $themed_content .= '<div id="map" style="width: 500px; height: 500px; position:relative;"></div>';

  return $themed_content;

And here is a sample function called to add bits to the Map object:

function pull_my_map_together(&$my_map) {
  // GoogleMap-related vars, etc.
  $color = 'red';
  $line_weight = 4;
  $line_opacity = '';
  $geodesic = true;

  // Prep the custom marker icon (adjust to your need)...
  $marker_icon = base_path() . path_to_theme() . '/images/marker_icons/marker.png';
  $icon_shadow = base_path() . path_to_theme() . '/images/marker_icons/shadow-marker.png';
  // Icon and Infowindow anchor parameters depend on your needs...
  $icon_key = $my_map->setMarkerIconKey($marker_icon, $icon_shadow, 20, 56, 20, 56);

  // You will likely have to do way more than this to pull together the 
  // location data you want to show...
  $result = db_query("SELECT from_address, to_address FROM {some_drupal_table}");

  while ($locationdata = db_fetch_object($result)) {
    // Cache the address if it's not already known...
    if (!$my_map->getCache($locationdata->from_address)) {
      $lonlat = $my_map->geoGetCoords($locationdata->from_address);
      $my_map->putCache($locationdata->from_address, $lonlat['lon'], $lonlat['lat']);
    };
    // Pull together the infobox marker verbiage...
    $infowin_text = "This is infowin content...";
    // Add the first map marker...
    $my_map->addMarkerByAddress($locationdata->from_address, 
      'From address title', $infowin_text, '', $marker_icon, $icon_shadow);

    if (!$my_map->getCache($locationdata->to_address)) {
      $lonlat = $my_map->geoGetCoords($locationdata->to_address);
      $my_map->putCache($locationdata->to_address, $lonlat['lon'], $lonlat['lat']);
    };

    // Add the second map marker...
    $my_map->addMarkerByAddress($locationdata->to_address, 
      'To address title', $infowin_text, $marker_icon, $icon_shadow);
    // Now add a polyline to the map connecting the two locations...
    $my_map->addPolyLineByAddress($locationdata->from_address, 
      $locationdata->to_address, false, $color, $line_weight, 
      $line_opacity, $geodesic);
  }
};

This should be enough to get you going...

Happy Mapping,
--Jim Salmons--
AKA DropaBalm Jambo


Credits
=========================
Developed by: Sohodojo Jim (Salmons, AKA 'DropaBalm Jambo')
Developed for the 'itch needing scratching' at: www.DropaBalm.com
Heavy-lifting (the good stuff made accessible by this minimal module): 
  Brad Wedell (See http://www.bradwedell.com/)
For full GoogleMapAPI documentation, updates, samples, etc. go to:
  http://code.google.com/p/php-google-map-api/
